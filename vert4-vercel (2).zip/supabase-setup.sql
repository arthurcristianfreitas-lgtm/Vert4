
-- ══════════════════════════════════════════════════════
-- TABELA: diagnostics (salva resultados completos)
-- ══════════════════════════════════════════════════════
create table if not exists diagnostics (
  id           uuid primary key default gen_random_uuid(),
  session_id   text,
  clinic       text,
  owner_name   text,
  secretary    text,
  whatsapp     text,
  instagram    text,
  profile      text,
  disc         text,
  answers      jsonb,
  fin_data     jsonb,
  verdict      text,
  tc           float,
  monthly_loss float,
  mixed        boolean default false,
  mixed_str    text,
  created_at   timestamptz default now()
);

alter table diagnostics enable row level security;
create policy "insert_diagnostics" on diagnostics for insert with check (true);
create index if not exists idx_diagnostics_created on diagnostics(created_at);
